﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_II
{
    class Empleados
    {

        private string codigo, nombre, dui;

        private double salario, afp, isss, descuento, salarioLiquido;


        public double AFP(double salario)
        {
            return salario * 0.075;
        }

        public double ISSS(double salario)
        {
            return salario * 0.03;
        }

        public double SalarioLiquido(double salario)
        {
            return salario - Descuento(salario);
        }

        public double Descuento(double salario)
        {
            return AFP(salario) + ISSS(salario);
        }

        public string Codigo
        {
            get { return codigo; }
            set { codigo = value; }
        }


        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string DUI
        {
            get { return dui; }
            set { dui = value; }
        }

        public double Salario
        {
            get { return salario; }

            set { salario = value; }
        }

        public double _afp
        {
            get { return afp; }

            set { afp = value; }
        }

        public double _isss
        {
            get { return isss; }
            set { isss = value; }
        }

        public double _descuento
        {
            get { return descuento; }
            set { descuento = value; }
        }

        public double _sLiquido
        {
            get { return salarioLiquido; }
            set { salarioLiquido = value; }
        }
    }
}
